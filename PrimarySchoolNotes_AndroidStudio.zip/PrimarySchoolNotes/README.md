# Primary School Notes (v2)

Offline Android app (Kotlin + Jetpack Compose) for Malawi Standard 5-8 study notes.
All notes live in `app/src/main/assets/data/*.json` (compiled from the old app's HTML files).

## Build
1. Copy the original images into the app, renamed to match the JSON:
   `python tools/prepare_images.py "<folder with the old images>"`
2. Open this folder in Android Studio (Koala or newer), let Gradle sync.
3. Run on a device/emulator, or Build > Build APK(s).

For a Play Store release use Build > Generate Signed Bundle / APK.
If you are replacing the already-published app, set `applicationId` in `app/build.gradle.kts`
to the original package and sign with the original keystore.

## Screens
Home (Standard 5-8, "continue reading", search) -> Subjects -> Topics -> Reader
(text size A-/A+, previous/next topic). Search covers every title and all text.

## Data format
`index.json` lists standards/subjects. `standardN.json` is Standard -> subjects -> units -> blocks;
block types: paragraph, heading, list (nested), table, image. Parser: `tools/build_notes_json.py`.
