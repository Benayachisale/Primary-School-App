package com.bctech.primarynotes.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.util.concurrent.ConcurrentHashMap

class NotesRepository(private val context: Context) {

    val standards = listOf(5, 6, 7, 8)

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }
    private val cache = ConcurrentHashMap<Int, StandardDoc>()

    /** Loads (and caches) one standard's notes from assets/data/standardN.json. */
    suspend fun standard(n: Int): StandardDoc = withContext(Dispatchers.IO) {
        cache[n] ?: run {
            val text = context.assets.open("data/standard$n.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            json.decodeFromString(StandardDoc.serializer(), text).also { cache[n] = it }
        }
    }

    // ---------------------------------------------------------------- search

    private class Entry(
        val standard: Int,
        val subjectId: String,
        val subjectName: String,
        val unitPos: Int,
        val title: String,
        val titleLower: String,
        val text: String,
        val textLower: String,
    )

    private val indexLock = Mutex()
    @Volatile private var index: List<Entry>? = null

    private suspend fun buildIndex(): List<Entry> = indexLock.withLock {
        index ?: withContext(Dispatchers.Default) {
            val out = ArrayList<Entry>()
            for (n in standards) {
                val doc = standard(n)
                for (s in doc.subjects) {
                    s.units.forEachIndexed { pos, u ->
                        val sb = StringBuilder()
                        u.blocks.forEach { collectText(it, sb) }
                        val text = sb.toString()
                        out += Entry(n, s.id, s.name, pos, u.title, u.title.lowercase(), text, text.lowercase())
                    }
                }
            }
            out.also { index = it }
        }
    }

    suspend fun search(query: String, limit: Int = 50): List<SearchHit> {
        val tokens = query.lowercase().split(Regex("\\s+")).filter { it.length >= 2 }
        if (tokens.isEmpty()) return emptyList()
        val entries = buildIndex()
        return withContext(Dispatchers.Default) {
            entries.asSequence()
                .mapNotNull { e ->
                    val hay = e.titleLower + "\n" + e.textLower
                    if (!tokens.all { hay.contains(it) }) return@mapNotNull null
                    val score = if (tokens.all { e.titleLower.contains(it) }) 2 else 0
                    score to e
                }
                .sortedByDescending { it.first }
                .take(limit)
                .map { (_, e) -> SearchHit(e.standard, e.subjectId, e.subjectName, e.unitPos, e.title, snippet(e, tokens[0])) }
                .toList()
        }
    }

    private fun snippet(e: Entry, token: String): String {
        val i = e.textLower.indexOf(token)
        if (i < 0) return ""
        val from = (i - 40).coerceAtLeast(0)
        val to = (i + 100).coerceAtMost(e.text.length)
        val body = e.text.substring(from, to).replace('\n', ' ').trim()
        return (if (from > 0) "…" else "") + body + (if (to < e.text.length) "…" else "")
    }

    private fun collectText(b: Block, sb: StringBuilder) {
        when (b) {
            is Block.Paragraph -> sb.append(b.text).append('\n')
            is Block.Heading -> sb.append(b.text).append('\n')
            is Block.ListBlock -> b.items.forEach { item ->
                sb.append(item.text).append('\n')
                item.children.forEach { collectText(it, sb) }
            }
            is Block.Table -> b.rows.forEach { row -> row.forEach { sb.append(it.text).append(' ') }; sb.append('\n') }
            is Block.Image -> Unit
        }
    }
}
