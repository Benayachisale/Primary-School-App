@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.data.LastRead
import com.bctech.primarynotes.data.ReaderPrefs

private val cardColors = listOf(Color(0xFF00693E), Color(0xFF6A1B9A), Color(0xFFB45309), Color(0xFF1565C0))

@Composable
fun HomeScreen(
    prefs: ReaderPrefs,
    standards: List<Int>,
    onStandard: (Int) -> Unit,
    onSearch: () -> Unit,
    onResume: (LastRead) -> Unit,
) {
    Scaffold(
        topBar = {
            NotesTopBar(title = "Primary School Notes", actions = {
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, contentDescription = "Search notes") }
            })
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            prefs.lastRead?.let { last ->
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        onClick = { onResume(last) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Continue reading", style = MaterialTheme.typography.labelLarge)
                            Text(
                                prettyTitle(last.unitTitle),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "Standard ${last.standard} · ${prettyTitle(last.subjectName)}",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }
            items(standards) { n ->
                Card(
                    onClick = { onStandard(n) },
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                    colors = CardDefaults.cardColors(containerColor = cardColors[(n - 5).coerceIn(0, 3)]),
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Standard", color = Color.White, fontSize = 18.sp)
                            Text("$n", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
