package com.bctech.primarynotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.bctech.primarynotes.ui.AppNav
import com.bctech.primarynotes.ui.PrimaryNotesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as NotesApp
        setContent {
            PrimaryNotesTheme {
                AppNav(repo = app.repo, prefs = app.prefs)
            }
        }
    }
}
