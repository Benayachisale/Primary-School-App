@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.StandardDoc

/** Lists the units/topics of one subject. */
@Composable
fun SubjectScreen(
    repo: NotesRepository,
    std: Int,
    subjectId: String,
    onBack: () -> Unit,
    onUnit: (Int) -> Unit,
) {
    val doc by produceState<StandardDoc?>(null, std) { value = repo.standard(std) }
    val subject = doc?.subjects?.firstOrNull { it.id == subjectId }
    Scaffold(
        topBar = { NotesTopBar(title = subject?.let { prettyTitle(it.name) } ?: "Standard $std", onBack = onBack) },
    ) { padding ->
        if (subject == null) {
            Loading(Modifier.padding(padding))
        } else {
            LazyColumn(modifier = Modifier.padding(padding)) {
                itemsIndexed(subject.units) { pos, u ->
                  Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUnit(pos) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = u.number?.toString() ?: "•",
                            modifier = Modifier.width(32.dp),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(prettyTitle(u.title), style = MaterialTheme.typography.bodyLarge)
                    }
                    HorizontalDivider()
                  }
                }
            }
        }
    }
}
