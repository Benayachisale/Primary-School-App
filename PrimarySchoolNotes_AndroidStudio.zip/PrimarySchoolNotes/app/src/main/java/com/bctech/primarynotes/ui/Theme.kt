package com.bctech.primarynotes.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF00693E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB7F0CE),
    onPrimaryContainer = Color(0xFF002111),
    secondary = Color(0xFF6A1B9A),
    background = Color(0xFFF6FBF8),
    surface = Color(0xFFF6FBF8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7CDBA1),
    onPrimary = Color(0xFF003919),
    primaryContainer = Color(0xFF00522A),
    onPrimaryContainer = Color(0xFFB7F0CE),
    secondary = Color(0xFFD7A8F0),
)

@Composable
fun PrimaryNotesTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
