@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.StandardDoc

/** Lists the subjects (Agriculture, English, ...) of one standard. */
@Composable
fun StandardScreen(
    repo: NotesRepository,
    std: Int,
    onBack: () -> Unit,
    onSubject: (String) -> Unit,
) {
    val doc by produceState<StandardDoc?>(null, std) { value = repo.standard(std) }
    Scaffold(topBar = { NotesTopBar(title = "Standard $std", onBack = onBack) }) { padding ->
        val d = doc
        if (d == null) {
            Loading(Modifier.padding(padding))
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(d.subjects) { s ->
                    val available = s.units.isNotEmpty()
                    Card(
                        onClick = { if (available) onSubject(s.id) },
                        enabled = available,
                        modifier = Modifier.fillMaxWidth().alpha(if (available) 1f else 0.5f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(prettyTitle(s.name), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                if (available) "${s.units.size} ${if (s.units.size == 1) "topic" else "topics"}" else "Notes coming soon",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }
        }
    }
}
