package com.bctech.primarynotes.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** One piece of content inside a unit. The JSON "type" field picks the subclass. */
@Serializable
sealed class Block {

    @Serializable
    @SerialName("paragraph")
    data class Paragraph(val text: String = "", val html: String? = null) : Block()

    @Serializable
    @SerialName("heading")
    data class Heading(val level: Int = 1, val text: String = "") : Block()

    @Serializable
    @SerialName("list")
    data class ListBlock(
        val ordered: Boolean = false,
        val marker: String? = null,
        val items: List<ListItem> = emptyList(),
    ) : Block()

    @Serializable
    @SerialName("table")
    data class Table(val rows: List<List<Cell>> = emptyList()) : Block()

    @Serializable
    @SerialName("image")
    data class Image(
        val src: String = "",
        val file: String = "",
        /** Path inside app/src/main/assets, e.g. images/standard_5_clip_image005.jpg */
        val path: String? = null,
        val alt: String? = null,
        val width: Int? = null,
        val height: Int? = null,
    ) : Block()
}

@Serializable
data class ListItem(
    val text: String = "",
    val html: String? = null,
    val images: List<Block> = emptyList(),
    val children: List<Block> = emptyList(),
)

@Serializable
data class Cell(
    val text: String = "",
    val header: Boolean = false,
    val colspan: Int = 1,
    val rowspan: Int = 1,
    val blocks: List<Block> = emptyList(),
)

@Serializable
data class NoteUnit(
    val id: String,
    val number: Int? = null,
    val title: String = "",
    val index: Int = 0,
    val credit: String? = null,
    val blocks: List<Block> = emptyList(),
)

@Serializable
data class Subject(
    val id: String,
    val name: String,
    val units: List<NoteUnit> = emptyList(),
    val empty: Boolean = false,
)

@Serializable
data class StandardDoc(
    val standard: Int,
    val title: String = "",
    val subjects: List<Subject> = emptyList(),
)

data class SearchHit(
    val standard: Int,
    val subjectId: String,
    val subjectName: String,
    val unitPos: Int,
    val title: String,
    val snippet: String,
)

data class LastRead(
    val standard: Int,
    val subjectId: String,
    val subjectName: String,
    val unitPos: Int,
    val unitTitle: String,
)
