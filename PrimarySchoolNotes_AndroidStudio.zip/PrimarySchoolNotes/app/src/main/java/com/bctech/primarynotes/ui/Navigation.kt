package com.bctech.primarynotes.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs

@Composable
fun AppNav(repo: NotesRepository, prefs: ReaderPrefs) {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = "home") {

        composable("home") {
            HomeScreen(
                prefs = prefs,
                standards = repo.standards,
                onStandard = { nav.navigate("standard/$it") },
                onSearch = { nav.navigate("search") },
                onResume = { nav.navigate("reader/${it.standard}/${it.subjectId}/${it.unitPos}") },
            )
        }

        composable(
            route = "standard/{std}",
            arguments = listOf(navArgument("std") { type = NavType.IntType }),
        ) { entry ->
            val std = entry.arguments!!.getInt("std")
            StandardScreen(
                repo = repo,
                std = std,
                onBack = { nav.popBackStack() },
                onSubject = { nav.navigate("subject/$std/$it") },
            )
        }

        composable(
            route = "subject/{std}/{sid}",
            arguments = listOf(
                navArgument("std") { type = NavType.IntType },
                navArgument("sid") { type = NavType.StringType },
            ),
        ) { entry ->
            val std = entry.arguments!!.getInt("std")
            val sid = entry.arguments!!.getString("sid")!!
            SubjectScreen(
                repo = repo,
                std = std,
                subjectId = sid,
                onBack = { nav.popBackStack() },
                onUnit = { pos -> nav.navigate("reader/$std/$sid/$pos") },
            )
        }

        composable(
            route = "reader/{std}/{sid}/{pos}",
            arguments = listOf(
                navArgument("std") { type = NavType.IntType },
                navArgument("sid") { type = NavType.StringType },
                navArgument("pos") { type = NavType.IntType },
            ),
        ) { entry ->
            ReaderScreen(
                repo = repo,
                prefs = prefs,
                std = entry.arguments!!.getInt("std"),
                subjectId = entry.arguments!!.getString("sid")!!,
                startPos = entry.arguments!!.getInt("pos"),
                onBack = { nav.popBackStack() },
            )
        }

        composable("search") {
            SearchScreen(
                repo = repo,
                onBack = { nav.popBackStack() },
                onOpen = { nav.navigate("reader/${it.standard}/${it.subjectId}/${it.unitPos}") },
            )
        }
    }
}
