@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.data.LastRead
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs
import com.bctech.primarynotes.data.StandardDoc

@Composable
fun ReaderScreen(
    repo: NotesRepository,
    prefs: ReaderPrefs,
    std: Int,
    subjectId: String,
    startPos: Int,
    onBack: () -> Unit,
) {
    val doc by produceState<StandardDoc?>(null, std) { value = repo.standard(std) }
    val subject = doc?.subjects?.firstOrNull { it.id == subjectId }
    var pos by rememberSaveable { mutableStateOf(startPos) }
    var scale by remember { mutableStateOf(prefs.textScale) }

    fun setScale(v: Float) {
        scale = v.coerceIn(0.8f, 1.8f)
        prefs.textScale = scale
    }

    Scaffold(
        topBar = {
            NotesTopBar(
                title = subject?.let { prettyTitle(it.name) } ?: "Standard $std",
                onBack = onBack,
                actions = {
                    val tint = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                    TextButton(onClick = { setScale(scale - 0.1f) }, colors = tint) { Text("A-", fontSize = 16.sp) }
                    TextButton(onClick = { setScale(scale + 0.1f) }, colors = tint) {
                        Text("A+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                },
            )
        },
    ) { padding ->
        if (subject == null || subject.units.isEmpty()) {
            Loading(Modifier.padding(padding))
        } else {
            val last = subject.units.lastIndex
            val p = pos.coerceIn(0, last)
            val unit = subject.units[p]

            LaunchedEffect(std, subjectId, p) {
                prefs.saveLast(LastRead(std, subjectId, subject.name, p, unit.title))
            }

            key(p) {
                LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                ) {
                    item {
                      Column {
                        Text(
                            text = unit.number?.let { "Unit $it" } ?: "",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary,
                        )
                        Text(
                            text = prettyTitle(unit.title),
                            fontSize = (24 * scale).sp,
                            lineHeight = (30 * scale).sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                        unit.credit?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                      }
                    }
                    items(unit.blocks) { b -> BlockView(b, scale) }
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedButton(onClick = { pos = p - 1 }, enabled = p > 0) { Text("Previous") }
                            Text("${p + 1} / ${last + 1}", style = MaterialTheme.typography.labelLarge)
                            Button(onClick = { pos = p + 1 }, enabled = p < last) { Text("Next") }
                        }
                    }
                }
            }
        }
    }
}
