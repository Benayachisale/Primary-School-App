package com.bctech.primarynotes.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Text size + "continue reading" bookmark, stored in SharedPreferences. */
class ReaderPrefs(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var textScale: Float
        get() = sp.getFloat("scale", 1f)
        set(v) { sp.edit().putFloat("scale", v).apply() }

    var lastRead: LastRead? by mutableStateOf(load())
        private set

    fun saveLast(item: LastRead) {
        lastRead = item
        sp.edit()
            .putInt("l_std", item.standard)
            .putString("l_sid", item.subjectId)
            .putString("l_sname", item.subjectName)
            .putInt("l_pos", item.unitPos)
            .putString("l_title", item.unitTitle)
            .apply()
    }

    private fun load(): LastRead? {
        val std = sp.getInt("l_std", -1)
        val sid = sp.getString("l_sid", null) ?: return null
        if (std < 0) return null
        return LastRead(
            std, sid,
            sp.getString("l_sname", "") ?: "",
            sp.getInt("l_pos", 0),
            sp.getString("l_title", "") ?: "",
        )
    }
}
