#!/usr/bin/env python3
"""Turn the original note images into small WebP files the app ships with.

    python tools/process_images.py <folder-with-original-images>

 - finds each image referenced by the notes (tools/rename_map.csv), searching the folder recursively
 - resizes to at most 720 px wide, converts to WebP (lossy or lossless, whichever is smaller)
 - writes app/src/main/assets/images/<clean_name>.webp
 - stores the real pixel size in the notes (so pictures lay out without jumping while loading)
 - rewrites tools/source/standardN.json and re-runs tools/split_data.py
Needs: pip install pillow
"""
import csv, io, json, os, shutil, subprocess, sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEST = os.path.join(ROOT, "app", "src", "main", "assets", "images")
MAX_W, Q_PHOTO, Q_ART = 720, 72, 82

if len(sys.argv) < 2:
    sys.exit(__doc__)
src = sys.argv[1]

by_rel, by_base = {}, {}
for r, _, fs in os.walk(src):
    for f in fs:
        full = os.path.join(r, f)
        by_rel[os.path.relpath(full, src).replace("\\", "/").lower()] = full
        by_base.setdefault(f.lower(), full)


def lookup(name):
    rel = name.replace("\\", "/").lower()
    return by_rel.get(rel) or next((v for k, v in by_rel.items() if k.endswith("/" + rel)), None) \
        or by_base.get(os.path.basename(rel))


def encode(im, photo):
    buf = io.BytesIO()
    im.save(buf, "WEBP", quality=Q_PHOTO if photo else Q_ART, method=6)
    best = buf.getvalue()
    if not photo:                                    # line art / clip art: lossless may be smaller
        b2 = io.BytesIO()
        im.save(b2, "WEBP", lossless=True, method=6)
        if len(b2.getvalue()) < len(best):
            best = b2.getvalue()
    return best


rows = list(csv.DictReader(open(os.path.join(HERE, "rename_map.csv"), encoding="utf-8")))
os.makedirs(DEST, exist_ok=True)
for f in os.listdir(DEST):
    os.remove(os.path.join(DEST, f))

new_path, dims, missing, before, after = {}, {}, [], 0, 0
for r in rows:
    old_path = r["suggested_path"]
    stem = os.path.splitext(os.path.basename(old_path))[0]
    target = f"images/{stem}.webp"
    if old_path in new_path:
        continue
    hit = lookup(r["file_on_disk"])
    if not hit:
        missing.append(r["file_on_disk"])
        continue
    im = Image.open(hit)
    photo = (im.format or "").upper() == "JPEG"
    im = im.convert("RGBA" if ("A" in im.mode or "transparency" in im.info) else "RGB")
    if im.width > MAX_W:
        im = im.resize((MAX_W, round(im.height * MAX_W / im.width)), Image.LANCZOS)
    data = encode(im, photo)
    with open(os.path.join(ROOT, "app", "src", "main", "assets", target), "wb") as fh:
        fh.write(data)
    new_path[old_path] = target
    dims[target] = (im.width, im.height)
    before += os.path.getsize(hit)
    after += len(data)

# rewrite the master notes: new .webp path + real pixel size on every image block
def fix(o):
    if isinstance(o, dict):
        if o.get("type") == "image":
            p = o.get("path")
            if p in new_path:
                o["path"] = new_path[p]
                o["width"], o["height"] = dims[new_path[p]]
            else:
                o.pop("path", None)          # image not supplied -> app simply skips it
        for v in o.values():
            fix(v)
    elif isinstance(o, list):
        for v in o:
            fix(v)

for n in (5, 6, 7, 8):
    p = os.path.join(HERE, "source", f"standard{n}.json")
    d = json.load(open(p, encoding="utf-8"))
    fix(d)
    json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

for r in rows:
    r["suggested_path"] = new_path.get(r["suggested_path"], r["suggested_path"])
with open(os.path.join(HERE, "rename_map.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=rows[0].keys())
    w.writeheader(); w.writerows(rows)

subprocess.run([sys.executable, os.path.join(HERE, "split_data.py")], check=True)
print(f"{len(new_path)} images: {before//1024} KB -> {after//1024} KB")
if missing:
    print(f"{len(set(missing))} not found (skipped): {sorted(set(missing))}")
