# Primary Notes (v1.2)

Offline Android app (Kotlin + Jetpack Compose) for Malawi Standard 5-8 study notes. By Benaya Chisale.

## Build
- Test APK:    `./gradlew assembleDebug`   -> app/build/outputs/apk/debug/app-debug.apk
- Small APK:   `./gradlew assembleRelease` -> app/build/outputs/apk/release/app-release.apk
  (R8 shrinking on; ~half the size of the debug APK). Use JDK 17.

### Signing your own release key (needed for Google Play)
    keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias notes
Create `keystore.properties` next to `settings.gradle.kts`:
    storeFile=release.jks
    storePassword=YOUR_PASSWORD
    keyAlias=notes
    keyPassword=YOUR_PASSWORD
Keep release.jks and the passwords safe: you need the same key for every future update.
Without keystore.properties, the release build is signed with the debug key (fine for sharing/testing).

## Edit text / numbers / links
`app/src/main/java/com/bctech/primarynotes/ui/AppInfo.kt`

## Fonts
`app/src/main/res/font/` (Product Sans + Garet Heavy, subset to Latin to save space).

## Data and images
`tools/source/standardN.json` is the master data. New/changed pictures:
    pip install pillow
    python tools/process_images.py "<folder with original images>"
This resizes + converts to WebP, updates the notes and regenerates `app/src/main/assets/data/`.
