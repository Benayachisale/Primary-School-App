@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.data.LastRead
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs

/** Reads one topic. Only that topic's small JSON file is loaded; the next one is prefetched. */
@Composable
fun ReaderScreen(
    repo: NotesRepository,
    prefs: ReaderPrefs,
    std: Int,
    subjectId: String,
    startPos: Int,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit,
) {
    val toc by rememberToc(repo)
    val subject = toc.valueOrNull()?.subject(std, subjectId)
    var pos by rememberSaveable { mutableStateOf(startPos) }
    var scale by remember { mutableStateOf(prefs.textScale) }
    fun setScale(v: Float) { scale = v.coerceIn(0.8f, 1.8f); prefs.textScale = scale }

    val last = (subject?.units?.lastIndex ?: 0)
    val p = pos.coerceIn(0, last)

    Scaffold(
        topBar = {
            NotesTopBar(
                title = subject?.let { prettyTitle(it.name) } ?: "Standard $std",
                onBack = onBack,
                actions = {
                    val tint = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                    TextButton(onClick = { setScale(scale - 0.1f) }, colors = tint) { Text("A-", fontSize = 16.sp) }
                    TextButton(onClick = { setScale(scale + 0.1f) }, colors = tint) { Text("A+", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    ThemeToggleButton(isDark, onToggleTheme)
                },
            )
        },
        bottomBar = {
            if (subject != null && subject.units.isNotEmpty()) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FilledTonalButton(onClick = { pos = p - 1 }, enabled = p > 0) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null)
                            Text("Previous")
                        }
                        Text("${p + 1} / ${last + 1}", style = MaterialTheme.typography.labelLarge)
                        Button(onClick = { pos = p + 1 }, enabled = p < last) {
                            Text("Next")
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                        }
                    }
                }
            }
        },
    ) { padding ->
        if (subject == null || subject.units.isEmpty()) {
            if (toc is Load.Failed) ErrorBox(Modifier.padding(padding))
            else ShimmerLines(Modifier.padding(padding).padding(16.dp))
        } else {
            val tocUnit = subject.units[p]
            val unitState by rememberLoad(tocUnit.id, peek = { repo.peekUnit(tocUnit.id) }) { repo.unit(tocUnit.id) }
            val unit = unitState.valueOrNull()

            LaunchedEffect(std, subjectId, p) {
                prefs.saveLast(LastRead(std, subjectId, subject.name, p, tocUnit.title))
                subject.units.getOrNull(p + 1)?.let { repo.prefetch(it.id) }
            }

            key(p) {
                LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                    item {
                        Column {
                            Text(
                                text = tocUnit.number?.let { "Unit $it" } ?: "",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary,
                            )
                            Text(
                                text = prettyTitle(tocUnit.title),
                                fontSize = (24 * scale).sp,
                                lineHeight = (30 * scale).sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(bottom = 8.dp),
                            )
                            unit?.credit?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            }
                        }
                    }
                    when {
                        unit != null -> items(unit.blocks) { b -> BlockView(b, scale) }
                        unitState is Load.Failed -> item { ErrorBox(Modifier.fillMaxWidth()) }
                        else -> item { ShimmerLines(lines = 10) }
                    }
                }
            }
        }
    }
}
