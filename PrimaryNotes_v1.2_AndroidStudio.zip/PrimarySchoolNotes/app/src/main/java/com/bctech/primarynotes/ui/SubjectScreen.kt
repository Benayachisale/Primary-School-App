@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bctech.primarynotes.data.NotesRepository

/** Topics (units) of one subject. */
@Composable
fun SubjectScreen(repo: NotesRepository, std: Int, subjectId: String, onBack: () -> Unit, onUnit: (Int) -> Unit) {
    val toc by rememberToc(repo)
    val subject = toc.valueOrNull()?.subject(std, subjectId)
    Scaffold(
        topBar = { NotesTopBar(title = subject?.let { prettyTitle(it.name) } ?: "Standard $std", onBack = onBack) },
    ) { padding ->
        if (subject == null) {
            if (toc is Load.Failed) ErrorBox(Modifier.padding(padding))
            else ShimmerLines(Modifier.padding(padding).padding(16.dp), lines = 8)
        } else {
            LazyColumn(modifier = Modifier.padding(padding)) {
                itemsIndexed(subject.units) { pos, u ->
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable { onUnit(pos) }.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(38.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                                Text(u.number?.toString() ?: "•", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(prettyTitle(u.title), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 14.dp))
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
