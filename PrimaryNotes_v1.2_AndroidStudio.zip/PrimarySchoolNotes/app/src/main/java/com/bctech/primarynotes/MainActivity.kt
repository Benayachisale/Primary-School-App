package com.bctech.primarynotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import com.bctech.primarynotes.ui.AppInfo
import com.bctech.primarynotes.ui.AppNav
import com.bctech.primarynotes.ui.PrimaryNotesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as NotesApp
        // Count a launch only on a fresh start (not on rotation).
        val showSupport = savedInstanceState == null &&
            app.prefs.registerLaunch().let { it == 1 || it % AppInfo.SUPPORT_POPUP_EVERY_N_LAUNCHES == 0 }
        setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (app.prefs.themeMode) {
                "dark" -> true
                "light" -> false
                else -> systemDark
            }
            PrimaryNotesTheme(darkTheme = dark) {
                AppNav(
                    repo = app.repo,
                    prefs = app.prefs,
                    showSupportOnStart = showSupport,
                    isDark = dark,
                    onToggleTheme = { app.prefs.setDark(!dark) },
                )
            }
        }
    }
}
