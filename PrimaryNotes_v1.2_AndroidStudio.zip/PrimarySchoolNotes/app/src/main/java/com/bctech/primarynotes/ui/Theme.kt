package com.bctech.primarynotes.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Color(0xFF227120),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5EDD0),
    onPrimaryContainer = Color(0xFF0A2E0A),
    secondary = Color(0xFF8B5E00),
    background = Color(0xFFF4FAF2),
    surface = Color(0xFFF4FAF2),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FD58A),
    onPrimary = Color(0xFF053A06),
    primaryContainer = Color(0xFF1E4D1C),
    onPrimaryContainer = Color(0xFFD5EDD0),
    secondary = Color(0xFFFFC857),
    background = Color(0xFF101410),
    surface = Color(0xFF101410),
)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun PrimaryNotesTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window
            if (window != null) {
                window.statusBarColor = (if (darkTheme) Color(0xFF0B2A0B) else Color(0xFF1B5E1A)).toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            }
        }
    }
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
