package com.bctech.primarynotes.ui

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.bctech.primarynotes.R

/** Product Sans (regular, italic, bold) + Garet Heavy for headings. Subsetted to keep the app small. */
val AppFont = FontFamily(
    Font(R.font.app_regular, FontWeight.Normal),
    Font(R.font.app_italic, FontWeight.Normal, FontStyle.Italic),
    Font(R.font.app_bold, FontWeight.Bold),
    Font(R.font.app_heavy, FontWeight.ExtraBold),
)

private fun TextStyle.app(heavy: Boolean = false) =
    copy(fontFamily = AppFont, fontWeight = if (heavy) FontWeight.ExtraBold else fontWeight)

private val base = Typography()

val AppTypography = Typography(
    displayLarge = base.displayLarge.app(true),
    displayMedium = base.displayMedium.app(true),
    displaySmall = base.displaySmall.app(true),
    headlineLarge = base.headlineLarge.app(true),
    headlineMedium = base.headlineMedium.app(true),
    headlineSmall = base.headlineSmall.app(true),
    titleLarge = base.titleLarge.app(true),
    titleMedium = base.titleMedium.app(),
    titleSmall = base.titleSmall.app(),
    bodyLarge = base.bodyLarge.app(),
    bodyMedium = base.bodyMedium.app(),
    bodySmall = base.bodySmall.app(),
    labelLarge = base.labelLarge.app(),
    labelMedium = base.labelMedium.app(),
    labelSmall = base.labelSmall.app(),
)
