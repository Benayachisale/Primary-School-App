package com.bctech.primarynotes.ui

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.em

private val smallWords = setOf("and", "of", "in", "the", "to", "for", "a", "an", "on", "at", "by", "or", "with", "from")
private val acronyms = setOf("HIV", "AIDS", "STI", "STIS", "MSCE", "PSLCE", "ICT", "TV", "DNA", "UN", "AU", "SADC", "ABC")

/** "SOIL FERTILITY AND HIV" -> "Soil Fertility and HIV". Mixed-case text is left alone. */
fun prettyTitle(s: String): String {
    val t = s.trim()
    val letters = t.filter { it.isLetter() }
    if (letters.isEmpty() || letters.count { it.isUpperCase() }.toFloat() / letters.length < 0.8f) return t
    return t.split(Regex("\\s+")).mapIndexed { i, w ->
        val bare = w.trim(',', '.', ':', ';', '(', ')')
        when {
            bare.uppercase() in acronyms -> w
            i > 0 && bare.lowercase() in smallWords -> w.lowercase()
            else -> w.lowercase().replaceFirstChar { it.uppercase() }
        }
    }.joinToString(" ")
}

private val tagRe = Regex("<(/?)(b|i|u|sub|sup|br)>")

private fun decode(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")

/** Converts the tiny HTML subset used in the JSON (b, i, u, sub, sup, br) to styled text. */
fun htmlToAnnotated(html: String): AnnotatedString = buildAnnotatedString {
    var last = 0
    var depth = 0
    for (m in tagRe.findAll(html)) {
        append(decode(html.substring(last, m.range.first)))
        val closing = m.groupValues[1] == "/"
        val tag = m.groupValues[2]
        if (tag == "br") {
            append("\n")
        } else if (closing) {
            if (depth > 0) { pop(); depth-- }
        } else {
            val style = when (tag) {
                "b" -> SpanStyle(fontWeight = FontWeight.Bold)
                "i" -> SpanStyle(fontStyle = FontStyle.Italic)
                "u" -> SpanStyle(textDecoration = TextDecoration.Underline)
                "sub" -> SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = 0.75.em)
                else -> SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 0.75.em)
            }
            pushStyle(style); depth++
        }
        last = m.range.last + 1
    }
    append(decode(html.substring(last)))
}
