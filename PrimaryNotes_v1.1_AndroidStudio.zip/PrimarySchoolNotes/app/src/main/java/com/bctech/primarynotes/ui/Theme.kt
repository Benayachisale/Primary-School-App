package com.bctech.primarynotes.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF227120),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5EDD0),
    onPrimaryContainer = Color(0xFF0A2E0A),
    secondary = Color(0xFF8B5E00),
    background = Color(0xFFF4FAF2),
    surface = Color(0xFFF4FAF2),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FD58A),
    onPrimary = Color(0xFF053A06),
    primaryContainer = Color(0xFF1E4D1C),
    onPrimaryContainer = Color(0xFFD5EDD0),
    secondary = Color(0xFFFFC857),
    background = Color(0xFF101410),
    surface = Color(0xFF101410),
)

@Composable
fun PrimaryNotesTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
