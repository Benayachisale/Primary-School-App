package com.bctech.primarynotes.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.R
import com.bctech.primarynotes.data.NotesRepository
import kotlinx.coroutines.delay

/** Logo + "by Benaya Chisale" while the small table of contents loads (search index loads in background). */
@Composable
fun SplashScreen(repo: NotesRepository, onFinished: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
        val t0 = System.currentTimeMillis()
        runCatching { repo.toc() }
        repo.warmUp()
        val left = 1500 - (System.currentTimeMillis() - t0)
        if (left > 0) delay(left)
        onFinished()
    }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AnimatedVisibility(visible, enter = fadeIn(tween(600)) + scaleIn(tween(600), initialScale = 0.85f)) {
            Image(
                painter = painterResource(R.drawable.app_logo),
                contentDescription = AppInfo.APP_NAME,
                modifier = Modifier.size(170.dp).clip(RoundedCornerShape(32.dp)),
            )
        }
        Spacer(Modifier.height(28.dp))
        Text("by", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Text(AppInfo.DEVELOPER, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        LinearProgressIndicator(Modifier.width(110.dp))
    }
}
