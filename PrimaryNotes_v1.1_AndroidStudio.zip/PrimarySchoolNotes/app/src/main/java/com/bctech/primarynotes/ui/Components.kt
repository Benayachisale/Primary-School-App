@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.Toc
import kotlinx.coroutines.CancellationException

// ---------------------------------------------------------------- loading state
sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Ready<T>(val value: T) : Load<T>
    data class Failed(val error: Throwable) : Load<Nothing>
}

fun <T> Load<T>.valueOrNull(): T? = (this as? Load.Ready<T>)?.value

/** Runs [block] off the main thread; [peek] gives an instant value when already cached. */
@Composable
fun <T> rememberLoad(key: Any?, peek: () -> T? = { null }, block: suspend () -> T): State<Load<T>> {
    val state = remember(key) { mutableStateOf<Load<T>>(peek()?.let { Load.Ready(it) } ?: Load.Loading) }
    LaunchedEffect(key) {
        if (state.value !is Load.Ready) {
            state.value = try {
                Load.Ready(block())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Load.Failed(e)
            }
        }
    }
    return state
}

@Composable
fun rememberToc(repo: NotesRepository): State<Load<Toc>> =
    rememberLoad(repo, peek = { repo.cachedToc }) { repo.toc() }

// ---------------------------------------------------------------------- top bar
@Composable
fun NotesTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    navigation: @Composable (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val c = MaterialTheme.colorScheme
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            when {
                navigation != null -> navigation()
                onBack != null -> IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = c.primary,
            titleContentColor = c.onPrimary,
            navigationIconContentColor = c.onPrimary,
            actionIconContentColor = c.onPrimary,
        ),
    )
}

// ------------------------------------------------------------ loading / errors
@Composable
fun ShimmerLines(modifier: Modifier = Modifier, lines: Int = 8) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val a by t.animateFloat(0.10f, 0.28f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Column(modifier.fillMaxWidth(), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        repeat(lines) { i ->
            Box(
                Modifier
                    .fillMaxWidth(if (i % 4 == 3) 0.6f else 1f)
                    .height(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = a)),
            )
        }
    }
}

@Composable
fun ErrorBox(modifier: Modifier = Modifier, message: String = "Couldn't load this. Please restart the app.") {
    Column(modifier.fillMaxSize().padding(32.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Text(message, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

/** Emoji icon per subject (works on every Android version, no extra libraries). */
fun subjectEmoji(name: String): String {
    val n = name.lowercase()
    return when {
        "agri" in n -> "🌾"
        "bible" in n -> "📖"
        "english" in n -> "📝"
        "expressive" in n -> "🎨"
        "science" in n -> "🔬"
        "social" in n -> "🌍"
        "chichewa" in n -> "💬"
        "life" in n -> "🌱"
        else -> "📚"
    }
}
