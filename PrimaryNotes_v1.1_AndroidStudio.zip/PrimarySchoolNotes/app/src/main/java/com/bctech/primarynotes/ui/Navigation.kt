package com.bctech.primarynotes.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs

@Composable
fun AppNav(repo: NotesRepository, prefs: ReaderPrefs, showSupportOnStart: Boolean) {
    val nav = rememberNavController()
    var supportPending by rememberSaveable { mutableStateOf(showSupportOnStart) }

    NavHost(navController = nav, startDestination = "splash") {

        composable("splash") {
            SplashScreen(repo) {
                nav.navigate("home") { popUpTo("splash") { inclusive = true } }
            }
        }

        composable("home") {
            HomeScreen(
                repo = repo,
                prefs = prefs,
                showSupportPopup = supportPending,
                onDismissSupport = { supportPending = false },
                onStandard = { nav.navigate("standard/$it") },
                onSearch = { nav.navigate("search") },
                onResume = { nav.navigate("reader/${it.standard}/${it.subjectId}/${it.unitPos}") },
                onAbout = { nav.navigate("about") },
                onSupport = { nav.navigate("support") },
                onContact = { nav.navigate("contact") },
                onThanks = { nav.navigate("thanks") },
            )
        }

        composable("standard/{std}", arguments = listOf(navArgument("std") { type = NavType.IntType })) { e ->
            val std = e.arguments!!.getInt("std")
            StandardScreen(repo, std, onBack = { nav.popBackStack() }, onSubject = { nav.navigate("subject/$std/$it") })
        }

        composable(
            "subject/{std}/{sid}",
            arguments = listOf(navArgument("std") { type = NavType.IntType }, navArgument("sid") { type = NavType.StringType }),
        ) { e ->
            val std = e.arguments!!.getInt("std")
            val sid = e.arguments!!.getString("sid")!!
            SubjectScreen(repo, std, sid, onBack = { nav.popBackStack() }, onUnit = { pos -> nav.navigate("reader/$std/$sid/$pos") })
        }

        composable(
            "reader/{std}/{sid}/{pos}",
            arguments = listOf(
                navArgument("std") { type = NavType.IntType },
                navArgument("sid") { type = NavType.StringType },
                navArgument("pos") { type = NavType.IntType },
            ),
        ) { e ->
            ReaderScreen(
                repo = repo, prefs = prefs,
                std = e.arguments!!.getInt("std"),
                subjectId = e.arguments!!.getString("sid")!!,
                startPos = e.arguments!!.getInt("pos"),
                onBack = { nav.popBackStack() },
            )
        }

        composable("search") {
            SearchScreen(repo, onBack = { nav.popBackStack() }, onOpen = { nav.navigate("reader/${it.standard}/${it.subjectId}/${it.unitPos}") })
        }
        composable("about") { AboutScreen(onBack = { nav.popBackStack() }, onSupport = { nav.navigate("support") }) }
        composable("support") { SupportScreen(onBack = { nav.popBackStack() }) }
        composable("contact") { ContactScreen(onBack = { nav.popBackStack() }) }
        composable("thanks") { ThanksScreen(onBack = { nav.popBackStack() }) }
    }
}
