@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.data.NotesRepository

/** Subjects of one standard, each with an icon. */
@Composable
fun StandardScreen(repo: NotesRepository, std: Int, onBack: () -> Unit, onSubject: (String) -> Unit) {
    val toc by rememberToc(repo)
    Scaffold(topBar = { NotesTopBar(title = "Standard $std", onBack = onBack) }) { padding ->
        when (val t = toc) {
            Load.Loading -> ShimmerLines(Modifier.padding(padding).padding(16.dp), lines = 8)
            is Load.Failed -> ErrorBox(Modifier.padding(padding))
            is Load.Ready -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(t.value.standard(std)?.subjects ?: emptyList()) { s ->
                    val available = s.units.isNotEmpty()
                    Card(
                        onClick = { if (available) onSubject(s.id) },
                        enabled = available,
                        modifier = Modifier.fillMaxWidth().alpha(if (available) 1f else 0.55f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(52.dp).background(MaterialTheme.colorScheme.surface, CircleShape), contentAlignment = Alignment.Center) {
                                Text(subjectEmoji(s.name), fontSize = 26.sp)
                            }
                            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                Text(prettyTitle(s.name), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    if (available) "${s.units.size} ${if (s.units.size == 1) "topic" else "topics"}" else "Notes coming soon",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                            if (!available) Icon(Icons.Default.Lock, null)
                        }
                    }
                }
            }
        }
    }
}
