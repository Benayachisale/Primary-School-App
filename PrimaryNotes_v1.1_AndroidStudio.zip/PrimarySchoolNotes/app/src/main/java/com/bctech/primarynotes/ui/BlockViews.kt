package com.bctech.primarynotes.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.bctech.primarynotes.data.Block
import com.bctech.primarynotes.data.Cell
import com.bctech.primarynotes.data.ListItem

/** Renders any content block. `scale` is the user's text-size multiplier. */
@Composable
fun BlockView(block: Block, scale: Float, depth: Int = 0) {
    when (block) {
        is Block.Paragraph -> RichText(block.text, block.html, scale)
        is Block.Heading -> HeadingView(block, scale)
        is Block.ListBlock -> ListView(block, scale, depth)
        is Block.Table -> TableView(block, scale)
        is Block.Image -> NoteImage(block)
    }
}

@Composable
private fun RichText(text: String, html: String?, scale: Float, bold: Boolean = false, base: Float = 17f) {
    val styled = remember(text, html) { if (html != null) htmlToAnnotated(html) else AnnotatedString(text) }
    Text(
        text = styled,
        fontSize = (base * scale).sp,
        lineHeight = (base * 1.45f * scale).sp,
        fontWeight = if (bold) FontWeight.Bold else null,
        modifier = Modifier.padding(vertical = 4.dp),
    )
}

@Composable
private fun HeadingView(h: Block.Heading, scale: Float) {
    val size = when (h.level) {
        0, 1 -> 20f
        2 -> 18.5f
        else -> 17f
    }
    Text(
        text = prettyTitle(h.text),
        fontSize = (size * scale).sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp),
    )
}

@Composable
private fun ListView(list: Block.ListBlock, scale: Float, depth: Int) {
    Column(Modifier.padding(start = (depth * 16).dp, top = 2.dp, bottom = 2.dp)) {
        list.items.forEachIndexed { i, item -> ListItemView(item, i, list.ordered, scale, depth) }
    }
}

@Composable
private fun ListItemView(item: ListItem, index: Int, ordered: Boolean, scale: Float, depth: Int) {
    val bullet = when {
        ordered -> "${index + 1}."
        depth == 0 -> "•"
        depth == 1 -> "◦"
        else -> "–"
    }
    Row(Modifier.fillMaxWidth()) {
        Text(
            text = bullet,
            fontSize = (17 * scale).sp,
            lineHeight = (17 * 1.45f * scale).sp,
            modifier = Modifier.width(if (ordered) 30.dp else 20.dp).padding(top = 4.dp),
        )
        Column(Modifier.weight(1f)) {
            if (item.text.isNotEmpty()) RichText(item.text, item.html, scale)
            item.images.forEach { BlockView(it, scale) }
            item.children.forEach { BlockView(it, scale, depth + 1) }
        }
    }
}

@Composable
private fun TableView(t: Block.Table, scale: Float) {
    if (t.rows.isEmpty()) return
    val cols = t.rows.maxOf { r -> r.sumOf { it.colspan.coerceAtLeast(1) } }.coerceAtLeast(1)
    val screenW = LocalConfiguration.current.screenWidthDp
    val colW = ((screenW - 32) / cols).coerceIn(96, 220).dp
    val border = MaterialTheme.colorScheme.outline
    Column(
        Modifier
            .padding(vertical = 8.dp)
            .horizontalScroll(rememberScrollState())
            .border(0.5.dp, border),
    ) {
        t.rows.forEach { row ->
            Row(Modifier.height(IntrinsicSize.Min)) {
                row.forEach { cell ->
                    Box(
                        Modifier
                            .width(colW * cell.colspan.coerceAtLeast(1))
                            .fillMaxHeight()
                            .border(0.5.dp, border)
                            .padding(6.dp),
                    ) { CellContent(cell, scale) }
                }
            }
        }
    }
}

@Composable
private fun CellContent(cell: Cell, scale: Float) {
    if (cell.blocks.isNotEmpty()) {
        Column { cell.blocks.forEach { BlockView(it, scale * 0.88f) } }
    } else {
        RichText(cell.text, null, scale, bold = cell.header, base = 15f)
    }
}

@Composable
private fun NoteImage(img: Block.Image) {
    val path = img.path ?: return
    AsyncImage(
        model = "file:///android_asset/$path",
        contentDescription = img.alt,
        contentScale = ContentScale.Inside,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    )
}
