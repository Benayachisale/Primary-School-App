package com.bctech.primarynotes

import android.app.Application
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs

class NotesApp : Application() {
    val repo by lazy { NotesRepository(this) }
    val prefs by lazy { ReaderPrefs(this) }
}
