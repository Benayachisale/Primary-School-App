@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.SearchHit
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(
    repo: NotesRepository,
    onBack: () -> Unit,
    onOpen: (SearchHit) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<SearchHit>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        if (query.trim().length < 2) {
            hits = emptyList()
            loading = false
            return@LaunchedEffect
        }
        delay(250)
        loading = true
        hits = repo.search(query)
        loading = false
    }

    Scaffold(topBar = { NotesTopBar(title = "Search notes", onBack = onBack) }) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                singleLine = true,
                label = { Text("Search all standards") },
            )
            if (loading) {
                Text("Searching…", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium)
            } else if (query.trim().length >= 2 && hits.isEmpty()) {
                Text("No results", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium)
            }
            LazyColumn {
                items(hits) { h ->
                  Column {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(h) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                    ) {
                        Text(prettyTitle(h.title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "Standard ${h.standard} · ${prettyTitle(h.subjectName)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        if (h.snippet.isNotEmpty()) {
                            Text(h.snippet, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    HorizontalDivider()
                  }
                }
            }
        }
    }
}
