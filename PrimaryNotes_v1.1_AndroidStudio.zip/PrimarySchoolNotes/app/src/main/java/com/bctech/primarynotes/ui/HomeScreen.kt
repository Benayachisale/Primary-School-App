@file:OptIn(ExperimentalMaterial3Api::class)

package com.bctech.primarynotes.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.R
import com.bctech.primarynotes.data.LastRead
import com.bctech.primarynotes.data.NotesRepository
import com.bctech.primarynotes.data.ReaderPrefs
import kotlinx.coroutines.launch

private val gradients = listOf(
    listOf(Color(0xFF2E7D32), Color(0xFF66BB6A)),
    listOf(Color(0xFF6A1B9A), Color(0xFFAB47BC)),
    listOf(Color(0xFFE65100), Color(0xFFFFA726)),
    listOf(Color(0xFF1565C0), Color(0xFF42A5F5)),
)

@Composable
fun HomeScreen(
    repo: NotesRepository,
    prefs: ReaderPrefs,
    showSupportPopup: Boolean,
    onDismissSupport: () -> Unit,
    onStandard: (Int) -> Unit,
    onSearch: () -> Unit,
    onResume: (LastRead) -> Unit,
    onAbout: () -> Unit,
    onSupport: () -> Unit,
    onContact: () -> Unit,
    onThanks: () -> Unit,
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val toc by rememberToc(repo)
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    fun go(action: () -> Unit) { scope.launch { drawerState.close(); action() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.app_logo), AppInfo.APP_NAME, Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
                    Column(Modifier.padding(start = 14.dp)) {
                        Text(AppInfo.APP_NAME, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("by ${AppInfo.DEVELOPER}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                DrawerEntry("Home", Icons.Default.Home) { go {} }
                DrawerEntry("Search notes", Icons.Default.Search) { go(onSearch) }
                DrawerEntry("About app", Icons.Default.Info) { go(onAbout) }
                DrawerEntry("Support us", Icons.Default.Favorite) { go(onSupport) }
                DrawerEntry("Contact us", Icons.Default.Email) { go(onContact) }
                DrawerEntry("Special thanks", Icons.Default.Star) { go(onThanks) }
            }
        },
    ) {
        Scaffold(
            topBar = {
                NotesTopBar(
                    title = AppInfo.APP_NAME,
                    navigation = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Menu") }
                    },
                    actions = {
                        val pulse by rememberInfiniteTransition(label = "pulse")
                            .animateFloat(1f, 1.22f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "p")
                        IconButton(onClick = onSupport) {
                            Icon(Icons.Default.Favorite, "Support us", tint = SupportAmber, modifier = Modifier.scale(pulse))
                        }
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Search notes") }
                    },
                )
            },
        ) { padding ->
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                prefs.lastRead?.let { last ->
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Card(
                            onClick = { onResume(last) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text("Continue reading", style = MaterialTheme.typography.labelLarge)
                                    Text(prettyTitle(last.unitTitle), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("Standard ${last.standard} · ${prettyTitle(last.subjectName)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("Choose your class", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                when (val t = toc) {
                    is Load.Ready -> items(t.value.standards) { st ->
                        val subjects = st.subjects.count { it.units.isNotEmpty() }
                        val g = gradients[(st.standard - 5).coerceIn(0, 3)]
                        Card(onClick = { onStandard(st.standard) }, modifier = Modifier.fillMaxWidth().aspectRatio(1f), shape = RoundedCornerShape(22.dp)) {
                            Box(Modifier.fillMaxSize().background(Brush.linearGradient(g))) {
                                Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                    Text("🎓", fontSize = 26.sp)
                                    Column {
                                        Text("Standard", color = Color.White, fontSize = 16.sp)
                                        Text("${st.standard}", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                                        Text("$subjects subjects", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                    is Load.Failed -> item(span = { GridItemSpan(maxLineSpan) }) { ErrorBox() }
                    Load.Loading -> item(span = { GridItemSpan(maxLineSpan) }) { ShimmerLines(lines = 6) }
                }
            }
        }
    }

    if (showSupportPopup) {
        SupportDialog(onDismiss = onDismissSupport, onMore = { onDismissSupport(); onSupport() })
    }
}

@Composable
private fun DrawerEntry(label: String, icon: ImageVector, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label) },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
    )
}
