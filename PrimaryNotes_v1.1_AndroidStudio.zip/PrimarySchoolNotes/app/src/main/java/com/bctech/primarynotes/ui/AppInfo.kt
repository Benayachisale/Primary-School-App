package com.bctech.primarynotes.ui

/** All editable app text, numbers and links live here. */
object AppInfo {
    const val APP_NAME = "Primary Notes"
    const val DEVELOPER = "Benaya Chisale"

    const val AIRTEL_NUMBER = "0992605260"
    const val TNM_NUMBER = "0881308848"
    const val WHATSAPP_DISPLAY = "0992605260"
    const val WHATSAPP_URL = "https://wa.me/265992605260"
    const val EMAIL = "chisalebenaya@gmail.com"
    const val FACEBOOK_URL = "https://www.facebook.com/Benaya.Chisale"
    const val WEBSITE_URL = "http://malawi-teachers.free.nf"
    const val WEBSITE_LABEL = "malawi-teachers.free.nf"
    const val FIRST_DEVELOPER = "Noel K Mhone"

    /** Support pop-up shows on the first launch and then every Nth launch. */
    const val SUPPORT_POPUP_EVERY_N_LAUNCHES = 3

    const val BIO = "Benaya Chisale is a primary school teacher currently teaching at Namisunju Primary " +
        "School in Zomba, Malawi. He is the founder of Malawi-teachers.free.nf and a tech enthusiast " +
        "who builds tools that make learning and teaching easier for Malawian learners and teachers."

    const val ABOUT_APP = "Primary Notes brings Standard 5 to 8 study notes to your phone. It is free, " +
        "works without internet, and is organised by subject and topic. Use Search to find any topic fast."

    const val SUPPORT_ASK = "Primary Notes is free for every learner and teacher in Malawi. If it helps " +
        "you, please support the work with any small amount. Every contribution counts, thank you!"

    val SUPPORT_USES = listOf(
        "Adding the missing notes (English, Chichewa and more subjects)",
        "Fixing mistakes and improving the notes and pictures",
        "Data bundles and tools to build and test new versions",
        "Keeping the app free and updated for everyone",
    )

    const val THANKS_TEXT = "A big thank you to Noel K Mhone, the developer of the first Primary Notes " +
        "app. His work gave learners across Malawi an easy way to study offline, and this new version " +
        "is built on the same blueprint he created. Thank you for the foundation."

    const val THANKS_TEACHERS = "Thanks also to the teachers who wrote and compiled the notes, and to " +
        "every learner and teacher who uses the app."
}
