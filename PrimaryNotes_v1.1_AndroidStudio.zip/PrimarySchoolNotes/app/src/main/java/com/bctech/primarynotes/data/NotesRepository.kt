package com.bctech.primarynotes.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/**
 * Lazy data access: a tiny table of contents (toc.json) is read first, each topic is read from
 * its own file only when opened, and the search index loads in the background.
 */
class NotesRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun <T> read(path: String, ser: KSerializer<T>): T =
        context.assets.open(path).bufferedReader(Charsets.UTF_8).use { json.decodeFromString(ser, it.readText()) }

    // ------------------------------------------------------------------ toc
    @Volatile var cachedToc: Toc? = null
        private set
    private val tocLock = Mutex()

    suspend fun toc(): Toc = tocLock.withLock {
        cachedToc ?: withContext(Dispatchers.IO) { read("data/toc.json", Toc.serializer()) }.also { cachedToc = it }
    }

    // ---------------------------------------------------------------- units
    private val unitCache = object : LinkedHashMap<String, NoteUnit>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, NoteUnit>?) = size > 12
    }

    fun peekUnit(id: String): NoteUnit? = synchronized(unitCache) { unitCache[id] }

    suspend fun unit(id: String): NoteUnit = withContext(Dispatchers.IO) {
        peekUnit(id) ?: read("data/units/$id.json", NoteUnit.serializer()).also {
            synchronized(unitCache) { unitCache[id] = it }
        }
    }

    /** Warm the cache for the next topic so "Next" feels instant. */
    fun prefetch(id: String) { scope.launch { runCatching { unit(id) } } }

    // --------------------------------------------------------------- search
    private class Entry(
        val std: Int, val sid: String, val sname: String, val pos: Int,
        val title: String, val titleLower: String, val text: String, val textLower: String,
    )

    private val indexLock = Mutex()
    @Volatile private var index: List<Entry>? = null

    private suspend fun buildIndex(): List<Entry> = indexLock.withLock {
        index ?: withContext(Dispatchers.Default) {
            val names = toc().standards.flatMap { it.subjects }.associate { it.id to it.name }
            read("data/search.json", ListSerializer(SearchRow.serializer())).map {
                Entry(it.s, it.i, names[it.i] ?: "", it.p, it.t, it.t.lowercase(), it.x, it.x.lowercase())
            }.also { index = it }
        }
    }

    /** Called from the splash screen: loads the search index quietly in the background. */
    fun warmUp() { scope.launch { runCatching { toc(); buildIndex() } } }

    suspend fun search(query: String, limit: Int = 50): List<SearchHit> {
        val tokens = query.lowercase().split(Regex("\\s+")).filter { it.length >= 2 }
        if (tokens.isEmpty()) return emptyList()
        val entries = buildIndex()
        return withContext(Dispatchers.Default) {
            entries.asSequence()
                .mapNotNull { e ->
                    val hay = e.titleLower + "\n" + e.textLower
                    if (!tokens.all { hay.contains(it) }) return@mapNotNull null
                    (if (tokens.all { e.titleLower.contains(it) }) 2 else 0) to e
                }
                .sortedByDescending { it.first }
                .take(limit)
                .map { (_, e) -> SearchHit(e.std, e.sid, e.sname, e.pos, e.title, snippet(e, tokens[0])) }
                .toList()
        }
    }

    private fun snippet(e: Entry, token: String): String {
        val i = e.textLower.indexOf(token)
        if (i < 0) return ""
        val from = (i - 40).coerceAtLeast(0)
        val to = (i + 100).coerceAtMost(e.text.length)
        return (if (from > 0) "…" else "") + e.text.substring(from, to).replace('\n', ' ').trim() +
            (if (to < e.text.length) "…" else "")
    }
}
