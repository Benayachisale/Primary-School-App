@file:OptIn(ExperimentalLayoutApi::class)

package com.bctech.primarynotes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bctech.primarynotes.R

@Composable
private fun InfoScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Scaffold(topBar = { NotesTopBar(title = title, onBack = onBack) }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) { content() }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit, onSupport: () -> Unit) {
    val ctx = LocalContext.current
    val uri = LocalUriHandler.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.1"
    }
    InfoScaffold("About app", onBack) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.developer),
                contentDescription = AppInfo.DEVELOPER,
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier.size(150.dp).clip(CircleShape).border(3.dp, MaterialTheme.colorScheme.primary, CircleShape),
            )
            Spacer(Modifier.height(12.dp))
            Text(AppInfo.DEVELOPER, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Developer of Primary Notes", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("🍎 Primary school teacher", "💻 Tech enthusiast", "🌐 Founder, Malawi-teachers").forEach { Pill(it) }
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("About the developer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(AppInfo.BIO, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "🌐 ${AppInfo.WEBSITE_LABEL}",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { runCatching { uri.openUri(AppInfo.WEBSITE_URL) } }.padding(vertical = 4.dp),
                )
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("About the app", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(AppInfo.ABOUT_APP, style = MaterialTheme.typography.bodyLarge)
                Text("Version $version", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(
            Modifier.fillMaxWidth().clickable(onClick = onSupport),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Favorite, null, tint = SupportAmber, modifier = Modifier.size(28.dp))
                Text("  Enjoying the app? Support us", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Pill(text: String) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun SupportScreen(onBack: () -> Unit) {
    InfoScaffold("Support us", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Favorite, null, tint = SupportAmber, modifier = Modifier.size(44.dp))
        }
        Text("Support Primary Notes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        SupportBody()
        Text("Thank you for helping keep learning free. 💚", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ContactRow(badge: @Composable () -> Unit, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            badge()
            Column(Modifier.padding(start = 14.dp)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun Badge(color: Color, content: @Composable () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun ContactScreen(onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    fun open(url: String) { runCatching { uri.openUri(url) } }
    InfoScaffold("Contact us", onBack) {
        Text("Questions, corrections or ideas? We'd love to hear from you.", style = MaterialTheme.typography.bodyLarge)
        ContactRow({ Badge(Color(0xFF25D366)) { Icon(Icons.Default.Call, null, tint = Color.White) } }, "WhatsApp", AppInfo.WHATSAPP_DISPLAY) { open(AppInfo.WHATSAPP_URL) }
        ContactRow({ Badge(Color(0xFFEA4335)) { Icon(Icons.Default.Email, null, tint = Color.White) } }, "Email", AppInfo.EMAIL) { open("mailto:${AppInfo.EMAIL}") }
        ContactRow({ Badge(Color(0xFF1877F2)) { Text("f", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) } }, "Facebook", "Benaya Chisale") { open(AppInfo.FACEBOOK_URL) }
        ContactRow({ Badge(MaterialTheme.colorScheme.primary) { Text("🌐", fontSize = 22.sp) } }, "Website", AppInfo.WEBSITE_LABEL) { open(AppInfo.WEBSITE_URL) }
    }
}

@Composable
fun ThanksScreen(onBack: () -> Unit) {
    InfoScaffold("Special thanks", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Star, null, tint = SupportAmber, modifier = Modifier.size(56.dp))
        }
        Text(AppInfo.FIRST_DEVELOPER, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary)
        Text("Developer of the first Primary Notes app", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(AppInfo.THANKS_TEXT, style = MaterialTheme.typography.bodyLarge)
                Text(AppInfo.THANKS_TEACHERS, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
