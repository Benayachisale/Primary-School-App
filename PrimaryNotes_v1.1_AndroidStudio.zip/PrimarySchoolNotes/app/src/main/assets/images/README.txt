Put the note images here (run tools/prepare_images.py to copy + rename them).
Names must match the "path" values in the JSON, e.g. standard_5_clip_image005.jpg
