# Primary Notes (v1.1)

Offline Android app (Kotlin + Jetpack Compose) for Malawi Standard 5-8 study notes. By Benaya Chisale.

## Build
1. Copy the original images into the app: `python tools/prepare_images.py "<folder with the old images>"`
2. Android Studio: open this folder, sync, Run. Or terminal (JDK 17): `./gradlew assembleDebug`
   -> `app/build/outputs/apk/debug/app-debug.apk`

## Edit text / numbers / links
Everything editable (bio, support message, numbers, links, pop-up frequency) is in
`app/src/main/java/com/bctech/primarynotes/ui/AppInfo.kt`.

## Data (lazy loading)
`tools/source/standardN.json` is the master data. After changing it run `python tools/split_data.py`
to regenerate `app/src/main/assets/data/` (toc.json, units/*.json, search.json).
