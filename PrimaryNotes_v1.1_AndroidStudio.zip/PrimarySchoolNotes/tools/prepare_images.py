#!/usr/bin/env python3
"""Copy the ORIGINAL note images into the app, renamed to the clean names the JSON expects.

Usage:
    python tools/prepare_images.py <folder-with-original-images> [app/src/main/assets/images]

The original folder is searched recursively (the old app kept them next to the HTML files
and in an images/ subfolder), and names are matched case-insensitively.
Uses tools/rename_map.csv (original name -> images/<clean name>).
"""
import csv
import os
import shutil
import sys

here = os.path.dirname(os.path.abspath(__file__))
if len(sys.argv) < 2:
    sys.exit(__doc__)
src = sys.argv[1]
dest = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "..", "app", "src", "main", "assets", "images")
os.makedirs(dest, exist_ok=True)

by_rel, by_base = {}, {}
for root, _, files in os.walk(src):
    for f in files:
        full = os.path.join(root, f)
        rel = os.path.relpath(full, src).replace("\\", "/").lower()
        by_rel[rel] = full
        by_base.setdefault(f.lower(), full)


def lookup(name):
    """Exact relative match first (e.g. images/df.png), then any file with that name."""
    rel = name.replace("\\", "/").lower()
    if rel in by_rel:
        return by_rel[rel]
    for k, v in by_rel.items():
        if k.endswith("/" + rel):
            return v
    return by_base.get(os.path.basename(rel))


copied, missing, seen = 0, [], set()
with open(os.path.join(here, "rename_map.csv"), encoding="utf-8") as fh:
    for row in csv.DictReader(fh):
        target = os.path.basename(row["suggested_path"])
        if target in seen:
            continue
        seen.add(target)
        hit = lookup(row["file_on_disk"])
        if hit:
            shutil.copyfile(hit, os.path.join(dest, target))
            copied += 1
        else:
            missing.append(row["file_on_disk"])

print(f"copied {copied} of {len(seen)} images into {os.path.normpath(dest)}")
if missing:
    print(f"\n{len(missing)} not found in {src}:")
    for m in missing:
        print("  ", m)
