#!/usr/bin/env python3
"""Convert the old "Primary School Notes" HTML assets into structured JSON.

Output layout (OUT_DIR):
  index.json              - standards, subjects, unit counts, file names
  standard5.json ... 8    - Standard -> subjects -> units -> blocks
  images_manifest.json    - every image reference, where it is used, suggested new path
  rename_map.csv          - old src -> suggested new relative path
  parse_report.json       - warnings / anomalies found while parsing
"""
import csv
import json
import os
import re
import sys
from collections import Counter, defaultdict
from html import escape as _escape


def escape(s):
    return _escape(s, quote=False)

from urllib.parse import unquote

from bs4 import BeautifulSoup, NavigableString, Tag

SRC_DIR = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/assets"
OUT_DIR = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/notes_json"

STANDARDS = {
    5: "Standard 5.html",
    6: "Standard 6.html",
    7: "Standard 7).html",
    8: "Standard 8.html",
}

INLINE = {"a", "span", "b", "strong", "i", "em", "u", "font", "sub", "sup", "small",
          "big", "code", "mark", "s", "strike", "label", "abbr", "cite", "q", "br", "img"}
SKIP = {"script", "style", "hr", "button", "head", "meta", "link", "noscript"}
KEEP_INLINE = {"b", "strong", "i", "em", "u", "sub", "sup", "br"}
UNIT_RE = re.compile(r"^\s*unit\.?\s*(\d+)\b[\s:.\-\u2013\u2014]*(.*)$", re.I | re.S)
UNIT_ANY = re.compile(r"\bunit\s*\d+", re.I)
CREDIT_RE = re.compile(r"\s*\(?\s*(?:written|compiled|prepared)(?:\s+by\b.*)?\)?\s*$", re.I)
INSTRUCTION_RE = re.compile(r"click\s+(?:on\s+)?any\s+of\s+the\s+units", re.I)

report = defaultdict(list)


def norm(s):
    return re.sub(r"\s+", " ", (s or "").replace("\xa0", " ")).strip()


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


# ----------------------------------------------------------------- images
def image_block(img, std):
    src = (img.get("src") or "").strip()
    file = unquote(src)
    absolute = False
    if file.lower().startswith("file:") or re.match(r"^[A-Za-z][:|]", file):
        absolute = True
        file = re.split(r"[\\/]", file)[-1]
    blk = {"type": "image", "src": src, "file": file}
    if absolute:
        blk["absolute_path"] = True
    if img.get("alt"):
        blk["alt"] = norm(img["alt"])
    for k in ("width", "height"):
        v = re.sub(r"\D", "", img.get(k, "") or "")
        if v:
            blk[k] = int(v)
    if src.startswith("data:"):
        blk["file"] = "(embedded data URI)"
        blk["src"] = "data:..."
    return blk


# ----------------------------------------------------------------- inline
def inline_html(nodes):
    out = []
    for n in nodes:
        if isinstance(n, NavigableString):
            out.append(escape(str(n).replace("\xa0", " ")))
        elif isinstance(n, Tag):
            if n.name == "img":
                continue
            if n.name == "br":
                out.append("<br>")
            elif n.name in KEEP_INLINE:
                tag = {"strong": "b", "em": "i"}.get(n.name, n.name)
                out.append(f"<{tag}>{inline_html(n.children)}</{tag}>")
            else:
                out.append(inline_html(n.children))
    return re.sub(r"\s+", " ", "".join(out)).strip()


def inline_text(nodes):
    parts = []
    for n in nodes:
        if isinstance(n, NavigableString):
            parts.append(str(n))
        elif isinstance(n, Tag):
            if n.name == "img":
                continue
            if n.name == "br":
                parts.append("\n")
            else:
                parts.append(inline_text(n.children))
    return "".join(parts)


def tidy_html(h, text):
    """Drop empty tags / edge <br>; return None unless real inline formatting remains."""
    prev = None
    while prev != h:
        prev = h
        h = re.sub(r"<(b|i|u|sub|sup)>\s*</\1>", "", h)
        h = re.sub(r"</(b|i|u)>(\s*)<\1>", r"\2", h)
    h = re.sub(r"^(?:\s*<br>)+|(?:<br>\s*)+$", "", h).strip()
    if not re.search(r"<(b|i|u|sub|sup)>", h):
        return None
    return h


def clean_text(s):
    s = s.replace("\xa0", " ")
    lines = [re.sub(r"[ \t\r\f\v]+", " ", l).strip() for l in s.split("\n")]
    return "\n".join(l for l in lines if l).strip()


def link_only(nodes):
    """True when the buffer is basically only in-page links (a table of contents)."""
    total = 0
    linked = 0
    anchors = 0
    for n in nodes:
        for s in ([n] if isinstance(n, NavigableString) else n.find_all(string=True)):
            t = norm(str(s))
            if not t:
                continue
            total += len(t)
            if any(p.name == "a" and (p.get("href") or "").startswith("#") for p in s.parents):
                linked += len(t)
        if isinstance(n, Tag):
            anchors += len([a for a in ([n] + n.find_all("a")) if a.name == "a" and (a.get("href") or "").startswith("#")])
    return total > 0 and anchors > 0 and linked / total >= 0.8


def make_text_blocks(nodes, std):
    """Turn a run of inline nodes into [paragraph?, image*] blocks."""
    blocks = []
    imgs = []
    for n in nodes:
        if isinstance(n, Tag):
            imgs.extend(n.find_all("img") if n.name != "img" else [n])
    text = clean_text(inline_text(nodes))
    if text:
        p = {"type": "paragraph", "text": text}
        h = tidy_html(inline_html(nodes), text)
        if h:
            p["html"] = h
        if link_only(nodes):
            p["_toc"] = True
        # strip a leading BR-split heading ("UNIT 3 TITLE<br>body...")
        blocks.append(p)
    for im in imgs:
        blocks.append(image_block(im, std))
    return blocks


# ------------------------------------------------------------------ walker
def flatten(node, std):
    return flatten_nodes(list(node.children), std)


def flatten_nodes(nodes, std):
    blocks = []
    buf = []

    def flush():
        nonlocal buf
        if buf:
            blocks.extend(make_text_blocks(buf, std))
            buf = []

    for c in nodes:
        if isinstance(c, NavigableString):
            buf.append(c)
            continue
        if not isinstance(c, Tag):
            continue
        name = c.name
        if name == "button" and any(k.startswith("accordion") for k in (c.get("class") or [])):
            flush()
            blocks.append({"type": "_subject", "name": norm(c.get_text(" "))})
            continue
        if name in SKIP:
            continue
        if name in INLINE:
            if name == "br":
                buf.append(c)
            elif name == "a" and not c.get_text(strip=True) and not c.find("img"):
                continue  # empty named anchor
            else:
                buf.append(c)
            continue
        flush()
        if re.fullmatch(r"h[1-6]", name):
            text = clean_text(inline_text(c.children))
            imgs = c.find_all("img")
            if text:
                h = {"type": "heading", "level": int(name[1]), "text": text}
                if link_only(list(c.children)):
                    h["_toc"] = True
                blocks.append(h)
            blocks.extend(image_block(i, std) for i in imgs)
        elif name == "p":
            blocks.extend(make_text_blocks(list(c.children), std)
                          if not c.find(["ul", "ol", "table", "div", "h1", "h2", "h3", "h4", "h5", "h6"])
                          else flatten(c, std))
        elif name in ("ul", "ol"):
            blocks.extend(list_blocks(c, std))
        elif name == "table":
            blocks.append(table_block(c, std))
        elif name == "li":  # stray li outside a list
            blocks.append({"type": "list", "ordered": False, "items": [list_item(c, std)]})
        else:  # div, header, center, section, blockquote, font, form, ...
            blocks.extend(flatten(c, std))
    flush()
    return blocks


def list_item(li, std):
    inline_nodes, children = [], []
    for c in li.children:
        if isinstance(c, Tag) and c.name in ("ul", "ol"):
            children.extend(list_blocks(c, std))
        elif isinstance(c, Tag) and c.name in ("table",):
            children.append(table_block(c, std))
        elif isinstance(c, Tag) and (c.name in ("p", "div") or re.fullmatch(r"h[1-6]", c.name)):
            if inline_nodes:
                inline_nodes.append(Tag(name="br"))
            inline_nodes.append(c)
        else:
            inline_nodes.append(c)
    text = clean_text(inline_text(inline_nodes))
    item = {"text": text}
    h = tidy_html(inline_html(inline_nodes), text)
    if h:
        item["html"] = h
    imgs = [image_block(i, std) for n in inline_nodes if isinstance(n, Tag)
            for i in (n.find_all("img") if n.name != "img" else [n])]
    if imgs:
        item["images"] = imgs
    if children:
        item["children"] = children
    return item


def list_blocks(ul, std):
    """Word exports put <p>, <div>, <h1>, <img> and nested <ul> directly inside <ul>.
    Keep everything, in document order: <li> -> list items, anything else -> normal blocks."""
    out, items, inline_buf = [], [], []
    ordered = ul.name == "ol"
    marker = (ul.get("type") or "").strip()

    def flush_items():
        if items:
            b = {"type": "list", "ordered": ordered, "items": items[:]}
            if marker:
                b["marker"] = marker
            out.append(b)
            items.clear()

    def flush_inline():
        nonlocal inline_buf
        if inline_buf:
            blocks = make_text_blocks(inline_buf, std)
            if blocks:
                flush_items()
                out.extend(blocks)
            inline_buf = []

    for c in ul.children:
        if isinstance(c, NavigableString):
            inline_buf.append(c)
        elif not isinstance(c, Tag) or c.name in SKIP:
            continue
        elif c.name == "li":
            flush_inline()
            items.append(list_item(c, std))
        elif c.name in ("ul", "ol"):
            flush_inline()
            nested = list_blocks(c, std)
            if items:
                items[-1].setdefault("children", []).extend(nested)
            else:
                out.extend(nested)
        elif c.name in INLINE:
            inline_buf.append(c)
        else:  # p, div, h1-h6, table, ... directly under <ul>
            flush_inline()
            blocks = flatten_nodes([c], std)
            if blocks:
                flush_items()
                out.extend(blocks)
    flush_inline()
    flush_items()
    return out


def table_block(tbl, std):
    rows = []
    for tr in tbl.find_all("tr"):
        if tr.find_parent("table") is not tbl:
            continue
        cells = []
        for td in tr.find_all(["td", "th"], recursive=False):
            blocks = flatten(td, std)
            texts = []
            for b in blocks:
                if b["type"] in ("paragraph", "heading"):
                    texts.append(b["text"])
                elif b["type"] == "list":
                    texts.extend(i["text"] for i in b["items"])
            cell = {"text": "\n".join(t for t in texts if t)}
            if td.name == "th":
                cell["header"] = True
            for k in ("colspan", "rowspan"):
                v = re.sub(r"\D", "", td.get(k, "") or "")
                if v and int(v) > 1:
                    cell[k] = int(v)
            if blocks and (len(blocks) > 1 or blocks[0]["type"] != "paragraph" or "html" in blocks[0]):
                cell["blocks"] = blocks
            cells.append(cell)
        if cells:
            rows.append(cells)
    return {"type": "table", "rows": rows}


# ------------------------------------------------------------- segmentation
def is_toc(b):
    if b.get("_toc"):
        return True
    if b["type"] == "table":
        txt = " ".join(c["text"] for r in b["rows"] for c in r)
        return len(UNIT_ANY.findall(txt)) >= 3 and len(txt) < 3000
    if b["type"] in ("paragraph", "heading"):
        if INSTRUCTION_RE.search(b["text"]):
            return True
        return len(UNIT_ANY.findall(b["text"])) >= 2 and len(b["text"]) < 3000
    return False


def split_credit(title):
    m = CREDIT_RE.search(title)
    if m:
        return norm(title[:m.start()]), norm(m.group(0).strip("() "))
    return title, None


def heading_match(b):
    """Return (number, title, remainder_paragraph_or_None) if block starts a unit."""
    if b["type"] not in ("paragraph", "heading"):
        return None
    text = b["text"]
    first_line, _, rest = text.partition("\n")
    m = UNIT_RE.match(first_line)
    if not m:
        return None
    if len(first_line) > 200:
        return None
    title = norm(m.group(2))
    return int(m.group(1)), title, norm(rest) if rest.strip() else None


def upper_ratio(t):
    letters = [c for c in t if c.isalpha()]
    return sum(c.isupper() for c in letters) / len(letters) if letters else 0


TAIL_UNIT_RE = re.compile(r"^(.*\S)\s+(UNIT\.?\s*\d+\s+[^a-z]{3,140})$")


def split_tail_heading(line):
    """'... some text UNIT 3 SANITATION' -> ('... some text', 'UNIT 3 SANITATION')."""
    m = TAIL_UNIT_RE.match(line.strip())
    if m and upper_ratio(m.group(2)) >= 0.85:
        return m.group(1), m.group(2)
    return None


def split_list_headings(b):
    """Word exports sometimes glue the next unit heading onto the last <li>. Pull it out."""
    if b["type"] != "list":
        return [b]
    out, cur = [], []
    for it in b["items"]:
        sp = split_tail_heading(it["text"].split("\n")[-1]) if it["text"] else None
        if sp and "children" not in it:
            lines = it["text"].split("\n")
            it = dict(it)
            it["text"] = "\n".join(lines[:-1] + [sp[0]])
            it.pop("html", None)
            cur.append(it)
            out.append({**{k: v for k, v in b.items() if k != "items"}, "items": cur})
            out.append({"type": "heading", "level": 0, "text": sp[1]})
            cur = []
        else:
            cur.append(it)
    if cur:
        out.append({**{k: v for k, v in b.items() if k != "items"}, "items": cur})
    return out


def split_embedded(b):
    """A multi-line paragraph may hide 'UNIT n TITLE' lines (bold after a <br>). Split there."""
    if b["type"] != "paragraph":
        return [b]
    if "\n" not in b["text"] and not split_tail_heading(b["text"]):
        return [b]
    out, buf = [], []
    for line in b["text"].split("\n"):
        sp = split_tail_heading(line)
        if sp:
            buf.append(sp[0])
            out.append({"type": "paragraph", "text": "\n".join(buf)})
            buf = []
            out.append({"type": "heading", "level": 0, "text": sp[1]})
            continue
        m = UNIT_RE.match(line)
        if m and len(line) <= 200 and upper_ratio(m.group(2)) >= 0.6 and norm(m.group(2)):
            if buf:
                out.append({"type": "paragraph", "text": "\n".join(buf)})
                buf = []
            out.append({"type": "heading", "level": 0, "text": line.strip()})
        else:
            buf.append(line)
    if buf:
        out.append({"type": "paragraph", "text": "\n".join(buf)})
    if len(out) == 1:
        return [b]
    return out


def segment(blocks, std, subject):
    blocks = [b for b in blocks if not is_toc(b)]
    if len(blocks) == 1 and blocks[0]["type"] == "paragraph" and \
            re.fullmatch(r"notes will be here\.?", blocks[0]["text"], re.I):
        report["placeholder_subject"].append(f"Std {std}: {subject} ('Notes will be here')")
        return []
    expanded = []
    for b in blocks:
        for x in split_embedded(b):
            expanded.extend(split_list_headings(x))
    units, cur = [], None

    def new(number, title, credit=None, implicit=False):
        nonlocal cur
        cur = {"number": number, "title": title, "blocks": []}
        if credit:
            cur["credit"] = credit
        if implicit:
            cur["implicit"] = True
        units.append(cur)

    for b in expanded:
        hm = heading_match(b)
        if hm:
            number, title, rest = hm
            title, credit = split_credit(title)
            new(number, title, credit)
            if rest:
                cur["blocks"].append({"type": "paragraph", "text": rest})
            continue
        if b["type"] == "paragraph" and UNIT_RE.match(b["text"]) and len(b["text"]) > 200:
            report["unit_heading_merged_with_body"].append(
                f"Std {std} / {subject}: {b['text'][:90]!r}")
        if cur is None:
            new(None, "Introduction", implicit=True)
        cur["blocks"].append(b)
    # drop an empty implicit intro
    units = [u for u in units if not (u.get("implicit") and not u["blocks"])]
    # an empty unit whose number reappears later with content was just a contents line
    filled = {u["number"] for u in units if u["blocks"] and u["number"] is not None}
    units = [u for u in units if u["blocks"] or u["number"] not in filled]

    # no "UNIT n" headings at all: fall back to the top-level headings as topics
    if len(units) == 1 and units[0].get("implicit"):
        heads = [b for b in units[0]["blocks"] if b["type"] == "heading"]
        if heads:
            lvl = min(h["level"] for h in heads)
            cands = [h for h in heads if h["level"] == lvl]
            caps = [h for h in cands if upper_ratio(h["text"]) >= 0.8]
            split_ids = {id(h) for h in (caps if 3 <= len(caps) < len(cands) else cands)}
            topics, cur = [], None
            for b in units[0]["blocks"]:
                if id(b) in split_ids:
                    cur = {"number": None, "title": b["text"], "blocks": [], "topic": True}
                    topics.append(cur)
                else:
                    if cur is None:
                        cur = {"number": None, "title": "Introduction", "blocks": [], "implicit": True}
                        topics.append(cur)
                    cur["blocks"].append(b)
            units = topics
            report["segmented_by_heading"].append(
                f"Std {std}: {subject}: {len(units)} topics split on level-{lvl} headings")
    return units


def strip_private(o):
    if isinstance(o, dict):
        return {k: strip_private(v) for k, v in o.items() if not k.startswith("_")}
    if isinstance(o, list):
        return [strip_private(x) for x in o]
    return o


def collect_images(o, acc):
    if isinstance(o, dict):
        if o.get("type") == "image":
            acc.append(o)
        for v in o.values():
            collect_images(v, acc)
    elif isinstance(o, list):
        for v in o:
            collect_images(v, acc)


# -------------------------------------------------------------------- main
def suggest_name(std, file):
    base = os.path.basename(file)
    base = re.sub(r"[^a-z0-9._-]+", "_", base.lower()).strip("_")
    base = re.sub(r"_+", "_", base).replace("_.", ".")
    return f"images/{base}"


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    index = {"source": "Primary School Notes (assets.zip)", "standards": []}
    manifest = []
    all_stats = {}

    for std, fname in STANDARDS.items():
        raw = open(os.path.join(SRC_DIR, fname), "rb").read()
        text = raw.decode("utf-8", errors="replace")
        if "\ufffd" in text:
            report["bad_utf8"].append(f"{fname}: {text.count(chr(0xfffd))} replacement chars")
        soup = BeautifulSoup(text, "lxml")
        subjects = []
        stream = flatten(soup.body, std)
        groups, cur_g = [], None
        for b in stream:
            if b["type"] == "_subject":
                cur_g = {"name": b["name"], "blocks": []}
                groups.append(cur_g)
            elif cur_g is not None:
                cur_g["blocks"].append(b)
        for g in groups:
            name = g["name"]
            units = segment(g["blocks"], std, name)
            for i, u in enumerate(units, 1):
                u["id"] = f"s{std}-{slug(name)}-{i:02d}"
                u["index"] = i
            sj = {"id": f"s{std}-{slug(name)}", "name": name, "units": units}
            if not units:
                sj["empty"] = True
                report["empty_subject"].append(f"Std {std}: {name}")
            elif len(units) == 1 and units[0].get("implicit"):
                report["unsegmented_subject"].append(
                    f"Std {std}: {name} ({len(units[0]['blocks'])} blocks, no 'UNIT n' headings)")
            nums = [u["number"] for u in units if u["number"] is not None]
            dups = [n for n, c in Counter(nums).items() if c > 1]
            if dups:
                report["duplicate_unit_numbers"].append(f"Std {std}: {name}: {sorted(dups)}")
            if nums:
                gaps = sorted(set(range(min(nums), max(nums) + 1)) - set(nums))
                if gaps:
                    report["missing_unit_numbers"].append(f"Std {std}: {name}: {gaps}")
            for u in units:
                if not u["blocks"]:
                    report["empty_unit"].append(f"Std {std}: {name}: UNIT {u['number']} {u['title']}")
            subjects.append(sj)

        doc = strip_private({"standard": std, "title": f"Standard {std}", "source_file": fname,
                             "subjects": subjects})
        # image manifest + per-image ids
        for sj in doc["subjects"]:
            for u in sj["units"]:
                imgs = []
                collect_images(u["blocks"], imgs)
                for im in imgs:
                    new = suggest_name(std, im["file"])
                    im["path"] = new
                    manifest.append({"standard": std, "subject": sj["name"], "unit_id": u["id"],
                                     "src": im["src"], "file": im["file"], "suggested_path": new,
                                     "absolute_path": im.get("absolute_path", False)})
        with open(os.path.join(OUT_DIR, f"standard{std}.json"), "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, separators=(",", ":"))
        n_units = sum(len(s["units"]) for s in doc["subjects"])
        n_blocks = sum(len(u["blocks"]) for s in doc["subjects"] for u in s["units"])
        all_stats[std] = {"subjects": len(doc["subjects"]), "units": n_units, "top_level_blocks": n_blocks}
        index["standards"].append({
            "standard": std, "file": f"standard{std}.json",
            "subjects": [{"id": s["id"], "name": s["name"], "units": len(s["units"]),
                          "empty": s.get("empty", False)} for s in doc["subjects"]]})

    # collisions in suggested names
    seen = defaultdict(set)
    for m in manifest:
        seen[m["suggested_path"]].add(m["file"].lower())
    for k, v in seen.items():
        if len(v) > 1:
            report["rename_collision"].append(f"{k} <- {sorted(v)}")
    # image used twice?
    uses = Counter((m["standard"], m["src"], m["unit_id"]) for m in manifest)
    for k, c in uses.items():
        if c > 1:
            report["image_used_multiple_times_in_one_unit"].append(f"Std {k[0]}: {k[1]} in {k[2]} x{c}")
    ext = Counter(os.path.splitext(m["file"])[1].lower() for m in manifest)

    json.dump(index, open(os.path.join(OUT_DIR, "index.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    json.dump({"total_references": len(manifest), "by_extension": dict(ext), "images": manifest},
              open(os.path.join(OUT_DIR, "images_manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    with open(os.path.join(OUT_DIR, "rename_map.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["standard", "original_src", "file_on_disk", "suggested_path"])
        for m in manifest:
            w.writerow([m["standard"], m["src"], m["file"], m["suggested_path"]])
    json.dump({"stats": all_stats, "warnings": report},
              open(os.path.join(OUT_DIR, "parse_report.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)

    print(json.dumps(all_stats, indent=1))
    for k, v in report.items():
        print(f"\n[{k}] {len(v)}")
        for line in v[:12]:
            print("  ", line)
        if len(v) > 12:
            print("   ...")


if __name__ == "__main__":
    main()
