#!/usr/bin/env python3
"""Split the big per-standard JSON files into the lazy-loading layout the app uses.

  tools/source/standardN.json  ->  app/src/main/assets/data/
      toc.json          tiny table of contents (standards > subjects > unit id/number/title)
      units/<id>.json   one file per unit/topic, loaded only when opened
      search.json       plain text of every unit, loaded in the background on first search

Run from the project root:  python tools/split_data.py
"""
import json
import os
import shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "tools", "source")
OUT = os.path.join(ROOT, "app", "src", "main", "assets", "data")


def collect_text(b, out):
    t = b.get("type")
    if t in ("paragraph", "heading"):
        out.append(b.get("text", ""))
    elif t == "list":
        for it in b.get("items", []):
            out.append(it.get("text", ""))
            for c in it.get("children", []):
                collect_text(c, out)
    elif t == "table":
        for row in b.get("rows", []):
            out.append(" ".join(c.get("text", "") for c in row))


def dump(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))


def main():
    shutil.rmtree(os.path.join(OUT, "units"), ignore_errors=True)
    os.makedirs(os.path.join(OUT, "units"))
    toc, search = {"standards": []}, []
    n_units = 0
    for std in (5, 6, 7, 8):
        with open(os.path.join(SRC, f"standard{std}.json"), encoding="utf-8") as f:
            doc = json.load(f)
        t_std = {"standard": std, "subjects": []}
        for s in doc["subjects"]:
            t_sub = {"id": s["id"], "name": s["name"], "units": []}
            if not s["units"]:
                t_sub["empty"] = True
            for pos, u in enumerate(s["units"]):
                unit = {k: u[k] for k in ("id", "number", "title", "index", "credit", "blocks") if k in u}
                dump(os.path.join(OUT, "units", u["id"] + ".json"), unit)
                t_sub["units"].append({"id": u["id"], "number": u.get("number"), "title": u["title"]})
                parts = []
                for b in u["blocks"]:
                    collect_text(b, parts)
                search.append({"s": std, "i": s["id"], "p": pos, "t": u["title"],
                               "x": "\n".join(p for p in parts if p)})
                n_units += 1
            t_std["subjects"].append(t_sub)
        toc["standards"].append(t_std)
    dump(os.path.join(OUT, "toc.json"), toc)
    dump(os.path.join(OUT, "search.json"), search)
    size = lambda p: os.path.getsize(os.path.join(OUT, p))
    unit_sizes = [os.path.getsize(os.path.join(OUT, "units", f)) for f in os.listdir(os.path.join(OUT, "units"))]
    print(f"{n_units} unit files (largest {max(unit_sizes)//1024} KB, median {sorted(unit_sizes)[len(unit_sizes)//2]//1024} KB)")
    print(f"toc.json {size('toc.json')//1024} KB | search.json {size('search.json')//1024} KB")


if __name__ == "__main__":
    main()
